package com.example.project1.Service;
import com.example.project1.Exception.ApiException;
import com.example.project1.Model.Cours;
import com.example.project1.Model.Student;
import com.example.project1.Model.Teacher;
import com.example.project1.Repository.CoursRepository;
import com.example.project1.Repository.StudentRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @RequiredArgsConstructor

public class StudentService {
    private final StudentRepository studentRepository ;

    public List<Student> getStudent() {
        return studentRepository.findAll();
    }

    public void addStudent(Student student )
    {
        studentRepository.save(student );
    }
    public Student  updateStudent(Integer id, Student  student ) {
        Student  oldStudent = studentRepository.findStudentsById(id) ;
        if (oldStudent == null) {
            throw new ApiException("id worng");
        }
        oldStudent.setId(student.getId());
        oldStudent.setName(student.getName()) ;
        oldStudent.setName(student .getName() ) ;
        studentRepository.save(oldStudent);

        return oldStudent;
    }

    public Student  deleteStudent(Integer id) {
        Student oldStudent = studentRepository.findStudentsById(id) ;

        if (oldStudent == null) {
            throw new ApiException("id worng");
        }

        return oldStudent;
    }
    public Student getStudentsById(Integer id){
        Student student =studentRepository .findStudentsById(id);
        if(student ==null){
            throw new ApiException("Wrong ID") ;
        }
        return student ;
    }

    public Student getByNameStudent(String name){
        Student student = studentRepository.findStudentsByName(name);
        if (student == null){
            throw new ApiException("Wrong name");
        }
        return student;
    }
    public Student getByAge(Integer age){
        Student student =studentRepository.findStudentsByAge(age);
        if(student == null){
            throw new ApiException("Wrong age");
        }
        return student;
    }
    public Student getByPassword(Integer Password){
        Student student =studentRepository.findStudentsByPassword(Password);
        if(student == null){
            throw new ApiException("Wrong Password");
        }
        return student;
    }
    public Student Check(Integer id, Integer  password) {
        Student  student = studentRepository .findStudentsById(id) ;
        if(student == null)
            throw new ApiException("id not Found");
        if(student.getPassword().equals(password))
            throw new ApiException("Password it is not correct ");
        return student;
    }


}