package com.example.project1.Controller;

import com.example.project1.Dto.ApiResponse;
import com.example.project1.Model.Cours;
import com.example.project1.Model.Student;
import com.example.project1.Service.StudentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/student")
public class StudentController {
    private StudentService studentService ;

    public StudentController (StudentService studentService) {

        this.studentService = studentService;
    }

    @GetMapping("/get")
    public ResponseEntity getStudent() {
        return ResponseEntity.status(200).body(studentService.getStudent());
    }

    @PostMapping("/add")
    public ResponseEntity addStudent(@RequestBody @Valid Student student) {
        studentService.addStudent(student);
        return ResponseEntity.status(200).body(new ApiResponse("Student Added!") );
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateStudent(@PathVariable Integer id, @RequestBody @Valid Student student ) {
        studentService.updateStudent(id, student );
        return ResponseEntity.status(200).body(new ApiResponse("Student update!"));
    }

    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deleteStudent(@PathVariable Integer id) {
        studentService.deleteStudent(id);
        return ResponseEntity.status(200).body(new ApiResponse("Student Delete!"));
    }
    @GetMapping("/byid")
    public ResponseEntity getStudentsById(@PathVariable Integer id){
        Student student = studentService .getStudentsById(id);
        return ResponseEntity.status(200).body(student);
    }
    @GetMapping("/byName")
    public ResponseEntity getByNameStudent(@PathVariable String name ){
        Student student =studentService .getByNameStudent(name );
        return ResponseEntity.status(200).body(student );
    }
    @GetMapping("/byAge")
    public ResponseEntity getByAge(@PathVariable Integer age){
        Student student =studentService .getByAge(age);
        return ResponseEntity.status(200).body(student);
    }
    @GetMapping("/byPassword")
    public ResponseEntity getByPassword(@PathVariable Integer Password){
        Student student =studentService .getByPassword(Password);
        return ResponseEntity.status(200).body(student);
    }
    @GetMapping("/check")
    public ResponseEntity Check(@RequestBody Integer id  , @PathVariable Integer Password)
    {
        return ResponseEntity.status(200).body(studentService.Check(id,Password));
    }


}
