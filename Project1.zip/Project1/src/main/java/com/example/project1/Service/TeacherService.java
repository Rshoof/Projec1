package com.example.project1.Service;

import com.example.project1.Exception.ApiException;
import com.example.project1.Model.Cours;
import com.example.project1.Model.Student;
import com.example.project1.Model.Teacher;
import com.example.project1.Repository.StudentRepository;
import com.example.project1.Repository.TeacherRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @RequiredArgsConstructor

public class TeacherService {
    private final TeacherRepository teacherRepository ;

    public List<Teacher> getTeacher() {
        return teacherRepository.findAll();
    }

    public void addTeacher(Teacher teacher)
    {
        teacherRepository.save(teacher );
    }
    public Teacher updateTeacher(Integer id, Teacher teacher ) {
        Teacher  oldTeacher = teacherRepository.findTeacherById(id) ;
        if (oldTeacher == null) {
            throw new ApiException("id worng");
        }
        oldTeacher.setId(oldTeacher.getId());
        oldTeacher.setName(oldTeacher.getName());
        teacherRepository.save(oldTeacher);

        return oldTeacher;

    }

    public Teacher  deleteTeacher(Integer id) {
        Teacher  oldteacher = teacherRepository.findTeacherById(id) ;

        if (oldteacher == null) {
            throw new ApiException("id worng");
        }

        return oldteacher;
    }
    public Teacher getTeacherById(Integer id){
        Teacher teacher =teacherRepository .findTeacherById(id);
        if(teacher ==null){
            throw new ApiException("Wrong ID") ;
        }
        return teacher ;
    }

    public Teacher getByName(String name){
        Teacher  teacher = teacherRepository.findTeacherByName(name);
        if (teacher == null){
            throw new ApiException("Wrong name");
        }
        return teacher;
    }
    public Teacher  getBySalary(Integer salary){
        Teacher teacher =teacherRepository.findTeacherBySalary(salary);
        if(teacher == null){
            throw new ApiException("Wrong salary");
        }
        return teacher;
    }
    public Teacher Checksalary(Integer id, Integer salary) {
        Teacher teacher = teacherRepository.findTeacherById(id) ;
        if(teacher == null)
            throw new ApiException("id not Found");
        if(teacher.getSalary().equals(salary))
            throw new ApiException("salary not correct ");
        return teacher;
    }

}