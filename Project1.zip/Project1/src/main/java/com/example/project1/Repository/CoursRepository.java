package com.example.project1.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.project1.Model.Cours;

import java.util.List;


@Repository
public interface CoursRepository extends JpaRepository<Cours,Integer>{
    Cours  findCoursById(Integer id);
  Cours findCoursByTeacherName(String TeacherName);
 Cours findCoursByEnrolledStudent (String EnrolledStudent);




}
