package com.example.project1.Controller;

import com.example.project1.Dto.ApiResponse;
import com.example.project1.Model.Cours;
import com.example.project1.Service.CoursService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/cours")
public class CoursController {
    private CoursService coursService ;

    public CoursController (CoursService coursService ) {

        this.coursService = coursService;
    }

    @GetMapping("/get")
    public ResponseEntity getCours() {
        return ResponseEntity.status(200).body(coursService.getCours());
    }

    @PostMapping("/add")
    public ResponseEntity addCours(@RequestBody @Valid Cours cours ) {
        coursService.addCours(cours);
        return ResponseEntity.status(200).body(new ApiResponse("Cours Added!") );
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateCours(@PathVariable Integer id, @RequestBody @Valid Cours cours ) {
        coursService.updateCours(id, cours);
        return ResponseEntity.status(200).body(new ApiResponse("Cours update!"));
    }

    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deleteCours(@PathVariable Integer id) {
        coursService.deleteCours(id);
        return ResponseEntity.status(200).body(new ApiResponse("Cours Delete!"));
    }
    @GetMapping("/byid/{id}")
    public ResponseEntity getCoursById(@PathVariable Integer id){
        Cours cours = coursService.getCoursById(id);
        return ResponseEntity.status(200).body(cours );
    }
    @GetMapping("/byEnrolledStudent")
    public ResponseEntity getCoursByEnrolledStudent(@PathVariable String EnrolledStudent){
        Cours cours =coursService.getCoursByEnrolledStudent(EnrolledStudent);
        return ResponseEntity.status(200).body(cours);
    }

}
