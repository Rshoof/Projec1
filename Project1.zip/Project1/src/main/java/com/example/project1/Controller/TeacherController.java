package com.example.project1.Controller;

import com.example.project1.Dto.ApiResponse;
import com.example.project1.Model.Cours;
import com.example.project1.Model.Student;
import com.example.project1.Model.Teacher;
import com.example.project1.Service.TeacherService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/v1/Teacher")
public class TeacherController {
    private TeacherService  teacherService ;

    public TeacherController (TeacherService teacherService) {

        this.teacherService = teacherService;
    }

    @GetMapping("/get")
    public ResponseEntity getTeacher() {
        return ResponseEntity.status(200).body(teacherService.getTeacher());
    }

    @PostMapping("/add")
    public ResponseEntity addTeacher(@RequestBody @Valid Teacher teacher ) {
        teacherService.addTeacher(teacher);
        return ResponseEntity.status(200).body(new ApiResponse("Teacher Added!"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateTeacher(@PathVariable Integer id, @RequestBody @Valid Teacher teacher ) {
        teacherService.updateTeacher(id, teacher);
        return ResponseEntity.status(200).body(new ApiResponse("Teacher update!"));
    }

    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deleteTeacher(@PathVariable Integer id) {
        teacherService.deleteTeacher(id);
        return ResponseEntity.status(200).body(new ApiResponse("Teacher Delete!"));
    }
    @GetMapping("/byid")
    public ResponseEntity getTeacherById(@PathVariable Integer id){
        Teacher  teacher = teacherService .getTeacherById(id);
        return ResponseEntity.status(200).body(teacher);
    }
    @GetMapping("/byName")
    public ResponseEntity getByName(@PathVariable String name ){
         Teacher teacher =teacherService .getByName(name );
        return ResponseEntity.status(200).body(teacher);
    }
    @GetMapping("/bysalary")
    public ResponseEntity getBySalary(@PathVariable Integer salary){
        Teacher teacher = teacherService.getBySalary(salary);
        return ResponseEntity.status(200).body(teacher);
    }
    @GetMapping("/Checksalary")
    public ResponseEntity Checksalary(@RequestBody Integer id, @PathVariable Integer salary)
    {
        return ResponseEntity.status(200).body(teacherService.Checksalary(id,salary));
    }

}
