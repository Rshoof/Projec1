package com.example.project1.Service;

import com.example.project1.Exception.ApiException;
import com.example.project1.Model.Cours;
import com.example.project1.Model.Student;
import com.example.project1.Repository.CoursRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @RequiredArgsConstructor

public class CoursService {
    private final CoursRepository coursRepository;

    public List<Cours> getCours() {
        return coursRepository.findAll();
    }

    public void addCours(Cours cours) {
        coursRepository.save(cours);
    }

    public Cours updateCours(Integer id, Cours cours) {
        Cours oldcours = coursRepository.findCoursById(id);
        if (oldcours == null) {
            throw new ApiException("id worng");
        }
        oldcours.setId(cours.getId());
        oldcours.setNeme(cours.getNeme());
        oldcours.setEnrolledStudent(cours.getEnrolledStudent() ) ;
        coursRepository.save(oldcours);

        return oldcours;
    }

    public Cours deleteCours(Integer id) {
        Cours oldcours = coursRepository.findCoursById(id);

        if (oldcours == null) {
            throw new ApiException("id worng");
        }

        return oldcours;
    }

    public Cours getCoursById(Integer id){
        Cours cours =coursRepository .findCoursById(id);
        if(cours==null){
            throw new ApiException("Wrong ID") ;
        }
        return cours ;
    }
    public Cours getCoursByTeacherName(String TeacherName){
        Cours cours = coursRepository.findCoursByTeacherName(TeacherName);
        if (cours == null){
            throw new ApiException("Wrong TeacherName");
        }
        return cours;
    }
    public Cours getCoursByEnrolledStudent(String EnrolledStudent){

        Cours cours =coursRepository.findCoursByEnrolledStudent(EnrolledStudent);
        if(cours == null){
            throw new ApiException("Wrong EnrolledStudent");
        }
        return cours;
    }

}
